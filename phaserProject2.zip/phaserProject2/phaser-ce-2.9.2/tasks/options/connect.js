module.exports = {
    root: {
        options: {
            keepalive: true,
            hostname: '*'
        }
    }
};
