module.exports = {

    options: {
        noImplicitAny: true
    },

    comments: {
        src: "./typescript/{phaser,pixi}.comments.d.ts"
    },

    defs: {
        src: "./typescript/{phaser,pixi}.d.ts"
    }

};
